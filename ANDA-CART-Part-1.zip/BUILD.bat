@echo off
title Building ANDA CART
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org then run this again. & pause & exit /b 1)
set CSC_IDENTITY_AUTO_DISCOVERY=false
call npm install || (echo npm install failed & pause & exit /b 1)
call npm run build || (echo Build failed & pause & exit /b 1)
echo.
echo Done! Your files are in the "dist" folder:
echo    ANDA CART Setup.exe   (installer)
echo    ANDA CART.exe         (portable)
start "" "%~dp0dist"
pause
