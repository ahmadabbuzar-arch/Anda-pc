'use strict';
/*
 * ANDA CART - Electron wrapper.
 * Loads the unmodified game from a local, offline "app://game/" origin.
 * (A custom origin is used instead of file:// because Chromium blocks ES-module
 *  imports and fetch() on file:// pages.)
 */
const { app, BrowserWindow, Menu, protocol, session } = require('electron');
const path = require('path');
const fs = require('fs');
const { Readable } = require('stream');

const APP_NAME = 'ANDA CART';
const IS_DEV = !app.isPackaged;
const START_WINDOWED = process.argv.includes('--windowed');
const ALLOW_DEVTOOLS = IS_DEV && process.argv.includes('--devtools');   // never in production

app.setName(APP_NAME);
if (process.platform === 'win32') app.setAppUserModelId('com.andacart.game');

// Must run before app is ready.
protocol.registerSchemesAsPrivileged([{
  scheme: 'app',
  privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true }
}]);

// Game-friendly Chromium switches.
app.commandLine.appendSwitch('ignore-gpu-blocklist');                       // keep WebGL on older GPUs
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required'); // audio/video autoplay
app.commandLine.appendSwitch('js-flags', '--max-old-space-size=4096');       // game embeds ~65 MB of data

const GAME_ROOT = path.resolve(IS_DEV ? path.join(__dirname, 'game') : path.join(process.resourcesPath, 'game'));
const ICON_PATH = path.join(__dirname, 'build', 'icon.ico');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.wasm': 'application/wasm',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
  '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav', '.mp4': 'video/mp4', '.webm': 'video/webm',
  '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json', '.fbx': 'application/octet-stream', '.bin': 'application/octet-stream',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.txt': 'text/plain; charset=utf-8'
};

let mainWindow = null;
let wantFullscreen = !START_WINDOWED;

function registerGameProtocol() {
  protocol.handle('app', async (request) => {
    try {
      const url = new URL(request.url);
      let rel = decodeURIComponent(url.pathname);
      if (rel === '/' || rel === '') rel = '/index.html';
      const file = path.resolve(GAME_ROOT, '.' + rel);
      const inside = path.relative(GAME_ROOT, file);
      if (inside.startsWith('..') || path.isAbsolute(inside)) return new Response('Forbidden', { status: 403 });
      const stat = await fs.promises.stat(file);
      if (!stat.isFile()) return new Response('Not found', { status: 404 });
      return new Response(Readable.toWeb(fs.createReadStream(file)), {
        status: 200,
        headers: {
          'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
          'Content-Length': String(stat.size),
          'Cache-Control': 'no-store'
        }
      });
    } catch (err) {
      return new Response('Not found', { status: 404 });
    }
  });
}

function toggleFullscreen() {
  if (!mainWindow) return;
  wantFullscreen = !mainWindow.isFullScreen();
  mainWindow.setFullScreen(wantFullscreen);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    title: APP_NAME,
    width: 1280,
    height: 720,
    minWidth: 800,
    minHeight: 450,
    fullscreen: wantFullscreen,
    fullscreenable: true,
    autoHideMenuBar: true,
    backgroundColor: '#05070d',
    show: false,
    icon: fs.existsSync(ICON_PATH) ? ICON_PATH : undefined,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      devTools: ALLOW_DEVTOOLS,
      autoplayPolicy: 'no-user-gesture-required',
      backgroundThrottling: false,
      spellcheck: false
    }
  });

  const wc = mainWindow.webContents;
  wc.setVisualZoomLevelLimits(1, 1);                 // no pinch / ctrl+wheel zoom

  // show once the page has painted (fail-safe after 20 s)
  const failSafe = setTimeout(() => { if (mainWindow && !mainWindow.isVisible()) mainWindow.show(); }, 20000);
  mainWindow.once('ready-to-show', () => { clearTimeout(failSafe); mainWindow.show(); mainWindow.focus(); });

  // no right-click menu (also stops the page's own context menu from appearing)
  wc.on('context-menu', (e) => e.preventDefault());
  wc.on('dom-ready', () => {
    wc.executeJavaScript("document.addEventListener('contextmenu',function(e){e.preventDefault();},true);").catch(() => {});
  });

  // keyboard shortcuts: F11 / Alt+Enter toggle fullscreen; block reload + devtools keys in production
  wc.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return;
    const k = String(input.key || '').toLowerCase();
    const ctrl = input.control || input.meta;
    if (k === 'f11' || (input.alt && k === 'enter')) { event.preventDefault(); toggleFullscreen(); return; }
    if (!ALLOW_DEVTOOLS && (k === 'f12' || (ctrl && input.shift && (k === 'i' || k === 'j' || k === 'c')) || (ctrl && k === 'u'))) {
      event.preventDefault(); return;
    }
    if (!IS_DEV && (k === 'f5' || (ctrl && k === 'r'))) { event.preventDefault(); return; }
  });

  // if the game's own requestFullscreen() is left (e.g. Esc), return to the fullscreen the player wants
  wc.on('leave-html-full-screen', () => {
    if (wantFullscreen && mainWindow && !mainWindow.isFullScreen()) mainWindow.setFullScreen(true);
  });

  // lock the window to the game: no navigation, no popups
  wc.on('will-navigate', (e, url) => { if (!url.startsWith('app://game/')) e.preventDefault(); });
  wc.setWindowOpenHandler(() => ({ action: 'deny' }));

  // recover from a renderer crash
  wc.on('render-process-gone', (_e, details) => {
    if (details.reason !== 'clean-exit' && mainWindow) mainWindow.reload();
  });

  wc.on('did-fail-load', (_e, code, desc, url) => console.error('Load failed:', code, desc, url));

  mainWindow.on('closed', () => { mainWindow = null; });
  mainWindow.loadURL('app://game/index.html');
}

// single instance
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
  });

  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);                    // no File/Edit/View menu bar
    registerGameProtocol();

    // only what the game needs: fullscreen + pointer lock (mouse look). Everything else denied.
    const allowed = new Set(['fullscreen', 'pointerLock', 'keyboardLock']);
    session.defaultSession.setPermissionRequestHandler((_wc, permission, cb) => cb(allowed.has(permission)));
    session.defaultSession.setPermissionCheckHandler((_wc, permission) => allowed.has(permission));

    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });

  app.on('window-all-closed', () => app.quit());
}
