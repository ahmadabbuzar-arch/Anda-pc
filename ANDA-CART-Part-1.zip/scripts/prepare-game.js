'use strict';
/*
 * Prepares the ./game folder that Electron loads.
 *
 *  1. Copies your ORIGINAL html (game-src/*.html) to game/index.html, byte for byte,
 *     except for ONE change: the three.js "addons" import-map URL that pointed to
 *     cdn.jsdelivr.net now points to a local folder (so the game works offline).
 *  2. Copies the matching three.js 0.160.0 addon files (GLTFLoader, FBXLoader and the
 *     helper modules they import) from node_modules/three into game/vendor/three-addons.
 *
 * Everything else in the game (models, audio, video, textures, code) is already
 * embedded inside the HTML and is not touched.
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SRC_DIR = path.join(ROOT, 'game-src');
const OUT_DIR = path.join(ROOT, 'game');
const THREE_JSM = path.join(ROOT, 'node_modules', 'three', 'examples', 'jsm');
const ADDON_OUT = path.join(OUT_DIR, 'vendor', 'three-addons');

const CDN_PREFIX = 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/';
const LOCAL_PREFIX = '/vendor/three-addons/';          // resolved against app://game/
const ENTRY_ADDONS = ['loaders/GLTFLoader.js', 'loaders/FBXLoader.js'];

function fail(msg) { console.error('\n[prepare-game] ERROR: ' + msg + '\n'); process.exit(1); }

// ---- locate the html ------------------------------------------------------
if (!fs.existsSync(SRC_DIR)) fail('Folder "game-src" is missing.');
const htmls = fs.readdirSync(SRC_DIR).filter(f => /\.html?$/i.test(f));
if (htmls.length === 0) fail('Put your game HTML file inside the "game-src" folder.');
if (htmls.length > 1) console.warn('[prepare-game] Several html files found, using: ' + htmls[0]);
const srcFile = path.join(SRC_DIR, htmls[0]);

// ---- three.js addons ------------------------------------------------------
const pkgPath = path.join(ROOT, 'node_modules', 'three', 'package.json');
if (!fs.existsSync(pkgPath)) fail('three.js is not installed. Run "npm install" first.');
const threeVersion = JSON.parse(fs.readFileSync(pkgPath, 'utf8')).version;
if (threeVersion !== '0.160.0') fail('three@' + threeVersion + ' found, but the game needs exactly 0.160.0.');

fs.rmSync(OUT_DIR, { recursive: true, force: true });
fs.mkdirSync(ADDON_OUT, { recursive: true });

// copy the entry files plus every relative module they (recursively) import
const seen = new Set();
function copyModule(rel) {
  if (seen.has(rel)) return;
  seen.add(rel);
  const from = path.join(THREE_JSM, rel);
  if (!fs.existsSync(from)) fail('Missing three.js addon file: ' + rel);
  const to = path.join(ADDON_OUT, rel);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
  const code = fs.readFileSync(from, 'utf8');
  const re = /(?:from|import)\s*\(?\s*['"](\.{1,2}\/[^'"]+)['"]/g;
  let m;
  while ((m = re.exec(code))) {
    copyModule(path.posix.normalize(path.posix.join(path.posix.dirname(rel), m[1])));
  }
}
ENTRY_ADDONS.forEach(copyModule);

// ---- html: swap the CDN url for the local one (latin1 = byte-exact round trip)
const html = fs.readFileSync(srcFile, 'latin1');
const parts = html.split(CDN_PREFIX);
const count = parts.length - 1;
if (count < 1) console.warn('[prepare-game] CDN import-map URL not found - html copied unchanged.');
fs.writeFileSync(path.join(OUT_DIR, 'index.html'), parts.join(LOCAL_PREFIX), 'latin1');

// ---- report ---------------------------------------------------------------
const left = (parts.join(LOCAL_PREFIX).match(/<script[^>]+src=["']https?:/gi) || []).length;
console.log('[prepare-game] OK');
console.log('  game html      : ' + path.basename(srcFile) + ' -> game/index.html (' + (html.length / 1048576).toFixed(1) + ' MB)');
console.log('  CDN refs fixed : ' + count);
console.log('  addon files    : ' + seen.size + ' copied to game/vendor/three-addons');
if (left) console.warn('  WARNING: ' + left + ' external <script src> tag(s) still reference the web.');
