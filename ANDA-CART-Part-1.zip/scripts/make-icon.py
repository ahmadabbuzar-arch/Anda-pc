"""Generate build/icon.ico (multi-size) and build/icon.png from the original logo.
The artwork is only resized - never edited. Requires: pip install pillow
Usage: python scripts/make-icon.py
"""
from PIL import Image
import os
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = Image.open(os.path.join(root, "build", "logo-original.png")).convert("RGBA")
sizes = [(256, 256), (128, 128), (96, 96), (64, 64), (48, 48), (32, 32), (24, 24), (20, 20), (16, 16)]
src.save(os.path.join(root, "build", "icon.ico"), format="ICO", sizes=sizes)
src.resize((512, 512), Image.LANCZOS).save(os.path.join(root, "build", "icon.png"))
print("icon.ico + icon.png written")
