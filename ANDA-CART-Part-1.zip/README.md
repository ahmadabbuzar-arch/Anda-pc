# ANDA CART - Windows desktop edition (Electron)

Your original game HTML is wrapped, not rewritten. Gameplay, graphics, audio, models,
story and code are untouched. The only edit is one URL: the three.js add-on import
(GLTFLoader/FBXLoader) pointed to a CDN; it now points to a local copy so the game runs offline.
Everything else (models, sounds, video, characters) was already embedded in your HTML.

## Build (on Windows 10/11 x64)

1. Install **Node.js LTS** from https://nodejs.org
2. Unzip this folder somewhere short, e.g. `C:\anda-cart-desktop`
3. Double-click **BUILD.bat**
   (or open a terminal in the folder and run `npm install` then `npm run build`)
4. When it finishes, the `dist` folder has:
   - `ANDA CART Setup.exe` - NSIS installer (desktop + Start menu shortcuts, uninstaller)
   - `ANDA CART.exe` - portable, no install needed

The first build downloads Electron and electron-builder (needs internet once). The built game itself is fully offline.

### No Windows PC / no setup? Build in the cloud
Push this folder to a GitHub repo, open **Actions > Build ANDA CART (Windows) > Run workflow**,
then download the `ANDA-CART-windows` artifact. (The game HTML is ~62 MB, under GitHub's 100 MB file limit.)

## Test without building
```
npm install
npm start                # fullscreen, like the real thing
npm run start:windowed   # windowed + DevTools (development only)
```

## Controls / behavior
- Keyboard + mouse as in your game (mouse-look uses pointer lock; Esc pauses as before)
- **F11** or **Alt+Enter**: toggle fullscreen. **Alt+F4**: quit
- Production build has no menu bar, no right-click menu, no DevTools (F12 / Ctrl+Shift+I blocked), no reload (F5 / Ctrl+R)
- Single instance only; saved settings (graphics mode) persist between launches

## Project layout
```
main.js                  Electron main process (fullscreen, offline app:// loader, lockdown)
scripts/prepare-game.js  copies your HTML -> game/ and vendors three.js add-ons
scripts/make-icon.py     regenerates build/icon.ico from build/logo-original.png (resize only)
game-src/                YOUR original game html (replace it to update the game)
build/icon.ico           multi-size icon (16-256 px) used for EXE, installer, uninstaller, shortcuts
package.json             electron-builder config (NSIS x64 + portable x64, name "ANDA CART")
```

## Updating the game later
Replace the html in `game-src/` and run `npm run build` again.
If you upgrade three.js inside the game, change `three` in `package.json` and `CDN_PREFIX` in `scripts/prepare-game.js` to match.

## Troubleshooting
- **"Cannot create symbolic link" during build**: turn on Windows *Developer Mode* (Settings > For developers) or run the terminal as Administrator, then rebuild.
- **SmartScreen "Windows protected your PC"**: the EXE is unsigned. Click *More info > Run anyway*. A code-signing certificate removes this.
- **Portable EXE starts slowly**: it unpacks the ~65 MB game to a temp folder on each launch; the installer version starts faster.
- **Black screen / slow**: update GPU drivers; the game's own graphics setting is saved between launches.
